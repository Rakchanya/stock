import json
import requests
import consonants as constant
import pandas as pd
import boto3
import logging
from io import StringIO
from botocore.exceptions import ClientError
import traceback

# Logging setup
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
sns = boto3.client("sns", region_name="eu-north-1")
ssm = boto3.client("ssm", region_name="eu-north-1")
s3 = boto3.client("s3")

def send_sns_success():
    try:
        success_sns_arn = ssm.get_parameter(
            Name=constant.SUCCESSNOTIFICATIONARN, WithDecryption=True
        )["Parameter"]["Value"]
        component_name = constant.COMPONENT_NAME
        env = ssm.get_parameter(
            Name=constant.ENVIRONMENT, WithDecryption=True
        )['Parameter']['Value']
        success_msg = constant.SUCCESS_MSG
        sns_message = f"{component_name} : {success_msg}"
        logger.info(f"Sending SNS Success Message: {sns_message}")
        return sns.publish(
            TopicArn="arn:aws:sns:eu-north-1:167140820201:successarn",
            Message=json.dumps({'default': sns_message}),
            Subject=f"{env} : {constant.COMPONENT_NAME}",
            MessageStructure="json"
        )
    except Exception:
        logger.error("Failed to send success SNS", exc_info=True)

def send_error_sns(error_message):
    try:
        error_sns_arn = ssm.get_parameter(
            Name=constant.ERRORNOTIFICATIONARN, WithDecryption=True
        )["Parameter"]["Value"]
        env = ssm.get_parameter(
            Name=constant.ENVIRONMENT, WithDecryption=True
        )['Parameter']['Value']
        component_name = constant.COMPONENT_NAME
        sns_message = f"{component_name} : {error_message}"
        logger.error(f"Sending SNS Error Message: {sns_message}")
        return sns.publish(
            TopicArn="arn:aws:sns:eu-north-1:167140820201:failedarn",
            Message=json.dumps({'default': sns_message}),
            Subject=f"{env} : {constant.COMPONENT_NAME}",
            MessageStructure="json"
        )
    except Exception:
        logger.error("Failed to send error SNS", exc_info=True)

def lambda_handler(event, context):
    try:
        # Get API URL from SSM
        url = ssm.get_parameter(Name=constant.urlapi, WithDecryption=True)["Parameter"]["Value"]

        # Fetch files from GitHub API
        response = requests.get(url)
        response.raise_for_status()
        files = response.json()

        # Extract CSV file URLs
        csv_files = [file['download_url'] for file in files if file['name'].endswith('.csv')]
        if not csv_files:
            raise ValueError("No CSV files found in the repository.")

        # Read the first CSV file
        csv_file = csv_files.pop()
        d = pd.read_csv(csv_file)

        # Process remaining CSVs
        dataframes = []
        for url in csv_files:
            file_name = url.split("/")[-1].replace(".csv", "")
            df = pd.read_csv(url)
            df['Symbol'] = file_name
            dataframes.append(df)

        if not dataframes:
            raise ValueError("No additional CSV files to process.")

        # Combine and merge datasets
        combined_df = pd.concat(dataframes, ignore_index=True)
        o_df = pd.merge(combined_df, d, on='Symbol', how='left')

        # Aggregate results
        o_df["timestamp"] = pd.to_datetime(o_df["timestamp"])
        filtered_df = o_df[(o_df['timestamp'] >= "2021-01-01") & (o_df['timestamp'] <= "2021-05-26")]
        result_time = filtered_df.groupby("Sector").agg({
            'open': 'mean',
            'close': 'mean',
            'high': 'max',
            'low': 'min',
            'volume': 'mean'
        }).reset_index()

        # Keep only specific sectors
        list_sector = ["TECHNOLOGY", "FINANCE"]
        result_time = result_time[result_time["Sector"].isin(list_sector)].reset_index(drop=True)

        # Write results to S3
        csv_buffer = StringIO()
        result_time.to_csv(csv_buffer, header=True, index=False)
        bucket_name = "rakshu3010"
        s3.put_object(Bucket=bucket_name, Key="stock_data.csv", Body=csv_buffer.getvalue())

        # Send SNS success notification
        send_sns_success()

        return {
            "statusCode": 200,
            "body": json.dumps("✅ Data has been written successfully to S3")
        }
    
    except Exception as e:
        error_msg = f"Error in Lambda execution: {str(e)}\n{traceback.format_exc()}"
        logger.error(error_msg, exc_info=True)
        send_error_sns(error_msg)
        return {
            "statusCode": 500,
            "body": json.dumps(error_msg)
            }
